Overleaf instructions
=====================
1.  Overleaf  >  New Project  >  Upload Project  >  select this zip file.
2.  Set the main document to  main.tex  (Menu > Main document) if not detected.
3.  Compiler: pdfLaTeX.  Compile twice so cross-references resolve.

Contents
    main.tex      the complete manuscript; nothing else is \input
    figures/      the eight rendered data figures (Figures 3 to 10)

Figures 1 and 2 (the system block diagram and the PRISMA flow) are drawn
natively in TikZ inside main.tex and need no image files.

The preamble sets \graphicspath{{figures/}{./}{../figures/}}, so the images
resolve whether they sit inside figures/ or directly beside main.tex.
